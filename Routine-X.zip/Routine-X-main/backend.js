import { auth, db } from "./firebase.js";

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
  collection,
  doc,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export function observarUsuarioLogado(callback) {
  return onAuthStateChanged(auth, callback);
}

export async function criarConta(nome, email, senha) {
  const credencial = await createUserWithEmailAndPassword(auth, email, senha);
  const usuario = credencial.user;

  await setDoc(doc(db, "usuarios", usuario.uid), {
    nome,
    email,
    criadoEm: serverTimestamp(),
    configuracoes: {
      tema: "dark",
      notificacoesAtivadas: true,
    },
  });

  return usuario;
}

export async function entrar(email, senha) {
  const credencial = await signInWithEmailAndPassword(auth, email, senha);
  return credencial.user;
}

export async function sair() {
  await signOut(auth);
}

export async function criarTarefa(userId, tarefa) {
  const tarefasRef = collection(db, "usuarios", userId, "tarefas");

  await addDoc(tarefasRef, {
    ...tarefa,
    criadaEm: serverTimestamp(),
    atualizadaEm: serverTimestamp(),
  });
}

export function observarTarefas(userId, callback) {
  const tarefasRef = collection(db, "usuarios", userId, "tarefas");
  const consulta = query(tarefasRef, orderBy("time", "asc"));

  return onSnapshot(consulta, (snapshot) => {
    const tarefas = snapshot.docs.map((documento) => ({
      ...documento.data(),
      id: documento.id,
    }));

    callback(tarefas);
  });
}

export async function atualizarTarefa(userId, tarefaId, dados) {
  const tarefaRef = doc(db, "usuarios", userId, "tarefas", tarefaId);

  await updateDoc(tarefaRef, {
    ...dados,
    atualizadaEm: serverTimestamp(),
  });
}

export async function excluirTarefa(userId, tarefaId) {
  const tarefaRef = doc(db, "usuarios", userId, "tarefas", tarefaId);
  await deleteDoc(tarefaRef);
}
